import java.util.HashMap;

public class Manager extends Employees {
  private String name;
  private int id;
  
HashMap<Integer, String> workers = new HashMap<Integer, String>();

  public void setWorker(int id, String name) {
    this.name = name;
    this.id = id;
    boolean check = true;
    for (Integer key : workers.keySet()) {
      if (id == key) {
        check = false;
      }

    }
    if (check == true) {
      workers.put(id, name);
    } else if (check != true) {
      System.out.println("The Id you entered is already registered, therefore it was not added to the database.");
    }

  }


  // method 3
  public String getName(int id) {
    String b = "";
    if (workers.get(id) != null) {
      b = "This id belongs to " + workers.get(id);
    } else {
      b = "You entered an invalid value";
    }
    return b;

  }

  public String getAll() {
    String a = "";
    for (Integer key : workers.keySet()) {
      a = "\n" + key + " " + workers.get(key);
      System.out.println(a);
    }
    return a;
  }

  public void getInfo(){
    System.out.println("The manager of this store is: " + workers.get(1000));
  }

  public String managerSalary(int id, int hours) {
    String a = "";
    double rate = 30.50;
    double base = 2000;
    double salary;
    String name = workers.get(id);
     salary = (base+(rate*hours));
     a = name + "'s wage for this week for working " + hours + " hours is: " + salary;
   
    return a;


}

  public String getInfo(int id){
    String name = "";

    if(workers.get(id) != null){
      name = workers.get(id);
    }

    return name;
  }

    public String getInfo(String name){
    String id = "There is no manager by that ID";
      
      if(name.equals("zeke")){
          id = "100";
        }
      else if(name.equals("giorno")){
        id = "101";
      }
      return id;
    }

  

}
