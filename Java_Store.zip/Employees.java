import java.util.HashMap;

public abstract class Employees extends Exception {

  public void setWorker(int id, String name) {
  }

  public abstract String getAll();

  public abstract String getInfo(String name);

  public abstract String getInfo(int id);

}
