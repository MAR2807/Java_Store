import java.util.HashMap;

public class Supervisor extends Employees{
private String name;
private int id;
  
HashMap<Integer, String> workers = new HashMap<Integer, String>();

  public void setWorker(int id, String name) {
    this.name = name;
    this.id = id;
    boolean check = true;
    for (Integer key : workers.keySet()) {
      if (id == key) {
        check = false;
      }

    }
    if (check == true) {
      workers.put(id, name);
    } else if (check != true) {
      System.out.println("The Id you entered is already registered, therefore it was not added to the database.");
    }

  }
      public void setWorker2(int id, String name) {
    this.name = name;
    this.id = id;
    boolean check = true;
    for (Integer key : workers.keySet()) {
      if (id == key) {
        check = false;
      }

    }
    if (check == true) {
      workers.put(id, name);
      System.out.println("You have added the supervisor: " + name + " with the id   of: " + id);
    } else if (check != true) {
      System.out.println("The Id you entered is already registered, therefore it was not added to the database.");
    }

  }
  
  public String duties(int id){
    String duty = "";
     if(id == 100){
       duty = "Zeke's duty today is to watch over the Store associates.";
     }
    else if(id == 101){
      duty = "Giorno's duty today is to evaluate Employee performances.";
    }
    else if(id == 102){
      duty = "Joseph's duty today is to organize the upcoming schedule.";
    }
    else if(id == 103){
      duty = "Mario's duty today is to send out payments to all Employees.";
    }
    else if(id == 104){
      duty = "Lucille's duty today is to order new products.";
    }
    return duty;
    
  }

  public String getInfo(int id){
    String name = "";

    if(workers.get(id) != null){
      name = workers.get(id);
    }

    return name;
  }

    public String getInfo(String name){
    String id = "There is no manager by that ID";
      
      if(name.equals("zeke")){
          id = "100";
        }
      else if(name.equals("giorno")){
        id = "101";
      }
      else if(name.equals("joseph")){
        id = "102";
      }
      else if(name.equals("mario")){
        id = "103";
      }
      else if(name.equals("lucille")){
        id = "104";
      }
      
      return id;
    }
    
  

  public String getAll() {
    String a = "";
    for (Integer key : workers.keySet()) {
      a = "\n" + key + " " + workers.get(key);
      System.out.println(a);
    }
    return a;
  }

  public String supervisorSalary(int id, int hours) {
    String a = "";
    double rate = 30.50;
    double salary;
    String name = workers.get(id);
     salary = (rate*hours);
     a = name + "'s wage for this week for working " + hours + " hours is: " + salary;
   
    return a;


}


  
    
}