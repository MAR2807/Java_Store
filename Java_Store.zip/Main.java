import java.util.Scanner;
import java.util.InputMismatchException;

class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    // constructor 1
    StoreAssociate walmart = new StoreAssociate();
    // create a hashmap with 5 peoples id as identifiers and their name as the item
    //call to method 1
    walmart.setWorker(1, "Daniel");
    walmart.setWorker(2, "Alex");
    walmart.setWorker(3, "John");
    walmart.setWorker(4, "Joe");
    walmart.setWorker(5, "Dana");

    // constructor 2
    Supervisor walmartSupervisor = new Supervisor();
    walmartSupervisor.setWorker(100, "Zeke");
    walmartSupervisor.setWorker(101, "Giorno");
    walmartSupervisor.setWorker(102, "Joseph");
    walmartSupervisor.setWorker(103, "Mario");
    walmartSupervisor.setWorker(104, "Lucille");

    // constructor 3
    Manager walmartManager = new Manager();
    walmartManager.setWorker(1000, "Francis");

    System.out.println("Do you want to see a list of all store associates in walmart?");

    // take user input
    String walmartAnswer = input.nextLine().toUpperCase();

    boolean check_w = false;
    do {
      // Implementing Switch
      switch (walmartAnswer) {
        case "Y":
  //call to method 2
          walmart.getAll();
          check_w = true;
          break;
        case "N":

          System.out.println("You have chosen not to see a list of all store associates at walmart.");
          check_w = true;
          break;
        default:
          System.out.println("You did not enter either Y or N, please try again.");
          walmartAnswer = input.nextLine().toUpperCase();

          break;
      }
    } while (check_w == false);

    System.out.println("Enter a number between 100 and 104 to see which supervisor's id is associated with that number");
    boolean check = false;
    while (check == false) {
      try {
        int empAnswer = input.nextInt();

        if (empAnswer < 100 || empAnswer > 104) {
          throw new InvalidException("You failed to enter a number between 100 and 104, please try again!");
        } else {
          check = true;
//call to method 3
          System.out.println(walmartSupervisor.getInfo(empAnswer));
        }
        //handle 1 exception
      } catch (InvalidException e) {
//call to method 4
        System.out.println(e.getMessage());
      }

    }

    // method to retrieve id of particular name

    Scanner input2 = new Scanner(System.in);
    Scanner input3 = new Scanner(System.in);

    System.out.println("Do you want to add an employee? type Y or N");
    String z = input2.nextLine().toUpperCase();
  
    switch (z) {

      case "Y":

        int empAnswer3 = 0;
        String empAnswer4 = "testing";
        boolean check2 = false;
        boolean check3 = false;
        while (check2 == false) {
          try {

            System.out.println("Enter an id for the employee");
            empAnswer3 = input2.nextInt();
            check2 = true;
          } catch (InputMismatchException ex) {

            String c = input2.nextLine();
            System.out.println("you entered: " + c);
            System.out.println("Enter only a number");
          }
        }

        while (check3 == false) {
          try {

            System.out.println("Enter a name for the employee");
            empAnswer4 = input3.nextLine();
            if (empAnswer4.matches("^[0-9].*")) {
              System.out.println("Only enter letters.");
            } else {
              check3 = true;
            }
//handle exception 2
          } catch (InputMismatchException ex) {
            System.out.println("Do not enter anything other than letters");
          }
        }
       boolean check_e = false;
        while(check_e == false){
          if (empAnswer3 < 100) {
          walmart.setWorker2(empAnswer3, empAnswer4);
          System.out.println("\n List of all store associates:");
          walmart.getAll();


          check_e = true;

        } else if (empAnswer3 > 99 && empAnswer3 < 1000) {
         
        
          walmartSupervisor.setWorker2(empAnswer3, empAnswer4);
         

          System.out.println("\nList of all Supervisors:");
          walmartSupervisor.getAll();


          check_e = true;

        } else if (empAnswer3 > 999 ) {
          System.out.println("\nOnly managers can have a 4 digit ID, please enter an ID below 1000.");
            empAnswer3 = input.nextInt();
        }
        else{
          System.out.println("\ninvalid id number");
          empAnswer3 = input.nextInt();
        }
        }
        

        break;
      case "N":

        System.out.println("\nYou have chosen not to enter an employee.");

        break;
    }



    boolean check_d = false;
    String duty_prompt = "\nEnter a supervisor's id number between 100 and 104 to see their duty";

    do {
      System.out.println(duty_prompt);
      int duty = input.nextInt();
      if (duty >= 100 && duty <= 104) {
//call to method 6
        System.out.println(walmartSupervisor.duties(duty)); 
        check_d = true;
      } else {
        duty_prompt = "\nYou did not enter a valid number, Please enter a number between 100 and 104";

      }

    } while (check_d == false);


    
    System.out.println("\nDo you want to see the list of store associate wages? Enter Y or N \n");
      Scanner input6 = new Scanner(System.in);
    String wages_prompt1 = input6.nextLine().toLowerCase();
    if(wages_prompt1.equals("y")){
        System.out.println("\nThe wages for all of the store associates this week are as follows: \n");
//Call to method 7
    System.out.println(walmart.associateSalary(1, 40));
    System.out.println(walmart.associateSalary(2, 32));
    System.out.println(walmart.associateSalary(3, 50));
    System.out.println(walmart.associateSalary(4, 55));
    System.out.println(walmart.associateSalary(5, 20));
    }
    else if(wages_prompt1.equals("n")){
      System.out.println("You have chosen not to see associate wages.");
    }
    else{
      System.out.println("You have enetered an invalid value.");
    }



    
    System.out.println("\nDo you want to see the list of supervisor wages? Enter Y or N \n");
      Scanner input7 = new Scanner(System.in);
    String wages_prompt2 = input7.nextLine().toLowerCase();
    if(wages_prompt2.equals("y")){
        System.out.println("\nThe wages for all of the supervisors this week are as follows: \n");
//Call to method 7
     System.out.println(walmartSupervisor.supervisorSalary(100, 50));
     System.out.println(walmartSupervisor.supervisorSalary(101, 60));
     System.out.println(walmartSupervisor.supervisorSalary(102, 62));
     System.out.println(walmartSupervisor.supervisorSalary(103, 70));
     System.out.println(walmartSupervisor.supervisorSalary(104, 45));
    }
    else if(wages_prompt2.equals("n")){
      System.out.println("You have chosen not to see associate wages.");
    }    
    else{
      System.out.println("You have enetered an invalid value.");
    }


    
    System.out.println("\nDo you want to see the managers wage? Enter Y or N \n");
      Scanner input8 = new Scanner(System.in);
    String wages_prompt3 = input8.nextLine().toLowerCase();
    if(wages_prompt3.equals("y")){
        System.out.println("\nThe wages for the manager this week is as follows: \n");
//Call to method 7
     System.out.println(walmartManager.managerSalary(1000, 50));
    
    }
    else if(wages_prompt3.equals("n")){
      System.out.println("You have chosen not to see the manager's wage.");
    } 
    else{
      System.out.println("You have enetered an invalid value.");
    }




    System.out.println("\nEnter a supervisor's name to see their id: Zeke, Giorno, Joseph, Mario and Lucille ");
  Scanner input5 = new Scanner(System.in);
String sv = input5.nextLine().toLowerCase();
    
    //call to overloaded method
    System.out.println(walmartSupervisor.getInfo(sv));


    input.close();

  }
}